package com.sbi.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.springboot.model.Vendor;
import com.sbi.springboot.repository.VendorRepository;

@Service
public class VendorService {

	@Autowired
	private VendorRepository venRepo;
	
	
	
	public Vendor saveVendor(Vendor vendor)
	{
		return venRepo.save(vendor);
	}
	
	public List<Vendor> getAllVenders()
	{
		return venRepo.findAll();
	}
}
