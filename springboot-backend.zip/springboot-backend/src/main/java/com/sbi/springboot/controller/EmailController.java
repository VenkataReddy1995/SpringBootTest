package com.sbi.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.springboot.model.EmailRecord;
import com.sbi.springboot.service.EmailRecordService;

@RestController
@RequestMapping("/api/emails")
public class EmailController {

	
	@Autowired
	private EmailRecordService emailRecordService;
	
	// get all employees
	@GetMapping("/vendors")
	public List<EmailRecord> getAllEmails(){
		return emailRecordService.getAllEmails();
	}		
	
	// create employee rest api
	@PostMapping("/vendors/create")
	public EmailRecord sendEmail(@RequestParam String message,@RequestParam String recipient) {
		return emailRecordService.sendEmail(recipient,message);
	}
}