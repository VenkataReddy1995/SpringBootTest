package com.sbi.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.springboot.model.EmailRecord;
import com.sbi.springboot.repository.EmailRecordRepository;

@Service
public class EmailRecordService {

	@Autowired
	private EmailRecordRepository emailRepo;
	
	
	
	
	public EmailRecord sendEmail(String recipient,String message) {
		System.out.println("sending email to::::"+recipient);
		System.out.println("Message::"+message);

		EmailRecord emailRecord=new EmailRecord();
		emailRecord.setMessage(message);
		emailRecord.setRecipient(recipient);
		return emailRepo.save(emailRecord);
	}
	
	/*
	 * public Vendor saveEmployee(Vendor vendor) { return venRepo.save(vendor); }
	 */
	
	public List<EmailRecord> getAllEmails()
	{
		return emailRepo.findAll();
	}
}
