package com.sbi.springboot.model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="email_records")
public class EmailRecord {
   

	@Id
	
	private Long id;
	private String recipient;
	private String message;
	public EmailRecord(Long id, String recipient, String message) {
		super();
		this.id = id;
		this.recipient = recipient;
		this.message = message;
	}
	public EmailRecord() {
		super();
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getRecipient() {
		return recipient;
	}
	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "EmailRecord [id=" + id + ", recipient=" + recipient + ", message=" + message + "]";
	}
	
	
	
}
