package com.sbi.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sbi.springboot.model.EmailRecord;


public interface EmailRecordRepository extends JpaRepository <EmailRecord, Long>{

	//void sendEmail(String message);

	//List<Email> findAllByOrderByTimestampDesc();

}
