package com.sbi.springboot.config;

//@Configuration
//@EnableWebSecurity
//@EnableMethodSecurity
public class SecurityConfig {
	/*
	 * 
	 * // User Creation
	 * 
	 * @Bean public UserDetailsService userDetailsService(PasswordEncoder encoder) {
	 * 
	 * // InMemoryUserDetailsManager UserDetails admin = User.withUsername("Amiya")
	 * .password(encoder.encode("123")) .roles("ADMIN", "USER") .build();
	 * 
	 * UserDetails user = User.withUsername("Ejaz") .password(encoder.encode("123"))
	 * .roles("USER") .build();
	 * 
	 * return new InMemoryUserDetailsManager(admin, user); }
	 * 
	 * // Configuring HttpSecurity
	 * 
	 * @Bean public SecurityFilterChain securityFilterChain(HttpSecurity http)
	 * throws Exception { return http.csrf().disable() .authorizeHttpRequests()
	 * .requestMatchers("/auth/welcome").permitAll() .and()
	 * .authorizeHttpRequests().requestMatchers("/auth/user/**").authenticated()
	 * .and()
	 * .authorizeHttpRequests().requestMatchers("/auth/admin/**").authenticated()
	 * .and().formLogin() .and().build(); }
	 * 
	 * // Password Encoding
	 * 
	 * @Bean public PasswordEncoder passwordEncoder() { return new
	 * BCryptPasswordEncoder(); }
	 */}
