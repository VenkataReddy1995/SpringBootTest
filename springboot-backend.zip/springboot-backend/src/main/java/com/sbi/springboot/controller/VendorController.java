package com.sbi.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.springboot.model.Vendor;
import com.sbi.springboot.service.VendorService;

@CrossOrigin(origins = "http://localhost:3001")
@RestController
@RequestMapping("/api/vendor/v1/")
public class VendorController {

	@Autowired
	private VendorService vendorService;
	
	// get all employees
	@GetMapping("/vendors")
	public List<Vendor> getAllEmployees(){
		return vendorService.getAllVenders();
	}		
	
	// create employee rest api
	@PostMapping("/vendors/create")
	public Vendor createVendor(@RequestBody Vendor vendor) {
		return vendorService.saveVendor(vendor);
	}
	
	/*
	 * // get employee by id rest api
	 * 
	 * @GetMapping("/vendors/oneVender/{id}") public ResponseEntity<Vendor>
	 * getVendorById(@PathVariable Long id) { Vendor employee =
	 * vendorRepository.findById(id) .orElseThrow(() -> new
	 * ResourceNotFoundException("vendor not exist with id :" + id)); return
	 * ResponseEntity.ok(employee); }
	 * 
	 * // update employee rest api
	 * 
	 * @PutMapping("/venders/update/{id}") public ResponseEntity<Vendor>
	 * updateVendor(@PathVariable Long id, @RequestBody Vendor venderDetails){
	 * Vendor employee = vendorRepository.findById(id) .orElseThrow(() -> new
	 * ResourceNotFoundException("Vendor not exist with id :" + id));
	 * 
	 * employee.setName(venderDetails.getName());
	 * employee.setEmailId(venderDetails.getEmailId());
	 * 
	 * Vendor updatedEmployee = vendorRepository.save(venderDetails); return
	 * ResponseEntity.ok(updatedEmployee); }
	 * 
	 * // delete employee rest api
	 * 
	 * @DeleteMapping("/venders/delete/{id}") public ResponseEntity<Map<String,
	 * Boolean>> deleteEmployee(@PathVariable Long id){ Vendor employee =
	 * vendorRepository.findById(id) .orElseThrow(() -> new
	 * ResourceNotFoundException("vendor not exist with id :" + id));
	 * 
	 * vendorRepository.delete(employee); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return
	 * ResponseEntity.ok(response); }
	 * 
	 */
}
