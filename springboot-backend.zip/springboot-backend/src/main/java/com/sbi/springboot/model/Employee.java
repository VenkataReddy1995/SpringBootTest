package com.sbi.springboot.model;

import jakarta.persistence.*;

@Entity
@Table(name = "employees")
public class Employee {
	
	@Id
	@Column(name = "email_id")
	private String email;
	
	@Column(name = "name")
	private String name;

	@Column(name = "designation")
	private String designation;
	

	private double ctc;
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getCtc() {
		return ctc;
	}

	public void setCtc(double ctc) {
		this.ctc = ctc;
	}

	public Employee() {
		
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Employee [email=" + email + ", name=" + name + ", designation=" + designation + ", ctc=" + ctc + "]";
	}
	
	
	
}
