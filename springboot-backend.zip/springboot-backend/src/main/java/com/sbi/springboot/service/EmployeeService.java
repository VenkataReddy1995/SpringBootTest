package com.sbi.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.springboot.model.Employee;
import com.sbi.springboot.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository empRepo;
	
	
	
	public Employee saveEmployee(Employee emp)
	{
		return empRepo.save(emp);
	}
	
	public List<Employee> getAllEmployees()
	{
		return empRepo.findAll();
	}
}
